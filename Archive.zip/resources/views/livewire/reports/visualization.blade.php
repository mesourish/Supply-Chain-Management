<?php

use Livewire\Volt\Component;
use App\Models\SalesOrder;
use App\Models\PurchaseOrder;
use App\Models\AccountPayable;
use App\Models\AccountReceivable;
use App\Models\Expense;
use App\Models\BinProductStock;
use App\Models\Product;
use App\Models\PaymentLog;
use Illuminate\Support\Facades\DB;

new class extends Component {
    // Flow Data (DFD)
    public $supplyChainFlow = [];
    public $financialFlow = [];

    public function mount()
    {
        // 1. Supply Chain Flow (DFD)
        $poTotals = PurchaseOrder::select('supplier_id', DB::raw('SUM(total_amount) as total'))
            ->where('status', '!=', 'cancelled')
            ->groupBy('supplier_id')
            ->with('supplier')->get();
        foreach($poTotals as $po) {
            $this->supplyChainFlow[] = ['Supplier: ' . ($po->supplier->name ?? 'Unknown'), 'Inventory', (float)$po->total];
        }
        
        $salesTotals = SalesOrder::select('customer_id', DB::raw('SUM(total_amount) as total'))
            ->where('status', '!=', 'cancelled')
            ->groupBy('customer_id')
            ->with('customer')->get();
        foreach($salesTotals as $sale) {
            $this->supplyChainFlow[] = ['Inventory', 'Customer: ' . ($sale->customer->name ?? 'Unknown'), (float)$sale->total];
        }

        // 2. Financial Cash Flow (DFD)
        $totalRevenue = PaymentLog::whereNotNull('account_receivable_id')->sum('amount');
        if ($totalRevenue > 0) {
            $this->financialFlow[] = ['Revenue (Sales)', 'Company Cash', (float)$totalRevenue];
        } else {
            // Fallback if no payments recorded
            $this->financialFlow[] = ['Revenue (Sales)', 'Company Cash', (float)SalesOrder::sum('total_amount')];
        }

        $expensesByCategory = Expense::select('category', DB::raw('SUM(amount) as total'))
            ->groupBy('category')
            ->orderByDesc('total')
            ->get();

        foreach($expensesByCategory as $exp) {
            $this->financialFlow[] = ['Company Cash', 'Expense: ' . ($exp->category ?: 'Uncategorized'), (float)$exp->total];
        }

        $poPayments = PaymentLog::whereNotNull('account_payable_id')->sum('amount');
        if ($poPayments > 0) {
            $this->financialFlow[] = ['Company Cash', 'Supplier Payments', (float)$poPayments];
        }
    }
}; ?>

<div class="max-w-7xl mx-auto sm:px-6 lg:px-8 py-8">
    <div class="flex items-center justify-between mb-8">
        <div>
            <h1 class="text-3xl font-black text-gray-900 tracking-tight">Enterprise Data Visualization</h1>
            <p class="text-gray-500 mt-1">Real-time Data Flow Diagrams (DFD) tracking resource movement</p>
        </div>
    </div>

    <div class="grid grid-cols-1 gap-8">
        <!-- Supply Chain Flow -->
        <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-150 relative overflow-hidden">
            <h3 class="text-lg font-black text-gray-900 mb-2">Supply Chain Volume Flow (DFD)</h3>
            <p class="text-sm text-gray-500 mb-6">Traces the volume of goods from Suppliers into Inventory, and out to Customers.</p>
            <div id="sankey_supply_chain" style="width: 100%; height: 500px;" wire:ignore></div>
        </div>

        <!-- Financial Flow -->
        <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-150 relative overflow-hidden">
            <h3 class="text-lg font-black text-gray-900 mb-2">Financial Cash Flow (DFD)</h3>
            <p class="text-sm text-gray-500 mb-6">Traces money from Revenue into the Company, and out to Expenses and Supplier Payments.</p>
            <div id="sankey_financial" style="width: 100%; height: 500px;" wire:ignore></div>
        </div>
    </div>

    <!-- Apache Echarts Sankey -->
    <script src="https://cdn.jsdelivr.net/npm/echarts@5.5.0/dist/echarts.min.js"></script>
    <script>
        document.addEventListener('livewire:initialized', () => {
            
            function renderEchartsSankey(elementId, flowDataRaw) {
                if (flowDataRaw.length === 0) return;

                const nodesMap = new Set();
                const links = [];
                
                flowDataRaw.forEach(item => {
                    nodesMap.add(item[0]);
                    nodesMap.add(item[1]);
                    links.push({
                        source: item[0],
                        target: item[1],
                        value: item[2]
                    });
                });

                const data = Array.from(nodesMap).map(name => ({ name }));

                const chartDom = document.getElementById(elementId);
                if (!chartDom) return;
                
                const myChart = echarts.init(chartDom);
                
                const option = {
                    tooltip: {
                        trigger: 'item',
                        triggerOn: 'mousemove',
                        backgroundColor: 'rgba(255, 255, 255, 0.95)',
                        borderColor: '#e2e8f0',
                        borderWidth: 1,
                        padding: [10, 15],
                        textStyle: { color: '#1e293b', fontSize: 14, fontFamily: 'Inter' }
                    },
                    series: {
                        type: 'sankey',
                        layout: 'none',
                        emphasis: { focus: 'adjacency' },
                        nodeAlign: 'left',
                        data: data,
                        links: links,
                        lineStyle: {
                            color: 'gradient',
                            curveness: 0.5,
                            opacity: 0.4
                        },
                        itemStyle: {
                            borderWidth: 0,
                            borderColor: '#fff',
                            borderRadius: 4
                        },
                        label: {
                            color: '#1e293b',
                            fontFamily: 'Inter',
                            fontSize: 13,
                            fontWeight: '600'
                        },
                        color: [
                            '#6366f1', '#10b981', '#f59e0b', '#ef4444', 
                            '#8b5cf6', '#ec4899', '#06b6d4', '#f43f5e', 
                            '#14b8a6', '#f59e0b'
                        ]
                    }
                };

                myChart.setOption(option);
                
                window.addEventListener('resize', function() {
                    myChart.resize();
                });
            }

            renderEchartsSankey('sankey_supply_chain', @json($supplyChainFlow));
            renderEchartsSankey('sankey_financial', @json($financialFlow));
        });
    </script>
</div>
