<?php

use Livewire\Volt\Component;
use App\Models\InventoryTransaction;
use App\Models\GoodsReceiptNote;
use Illuminate\Support\Facades\DB;

new class extends Component {
    public $inventoryFlow = [];

    public function mount()
    {
        if (!auth()->user()->can('view inventory')) {
            abort(403);
        }

        $this->loadData();
    }

    public function loadData()
    {
        // Calculate Flow: Supplier -> Warehouse -> Product based on historical GRN receipts
        $txs = InventoryTransaction::where('type', 'IN')
            ->where('reference_type', GoodsReceiptNote::class)
            ->with(['grn.purchaseOrder.supplier', 'toBin.warehouse', 'product'])
            ->get();

        $supplierToWarehouse = [];
        $warehouseToProduct = [];

        foreach ($txs as $tx) {
            $supplierName = $tx->grn->purchaseOrder->supplier->name ?? 'Unknown Supplier';
            $warehouseName = $tx->toBin->warehouse->name ?? 'Unknown Warehouse';
            $productName = $tx->product->name ?? 'Unknown Product';
            $qty = (float) $tx->quantity;

            // Aggregate Supplier -> Warehouse
            $s2wKey = $supplierName . '|' . $warehouseName;
            if (!isset($supplierToWarehouse[$s2wKey])) {
                $supplierToWarehouse[$s2wKey] = ['from' => 'Supplier: ' . $supplierName, 'to' => 'Warehouse: ' . $warehouseName, 'qty' => 0];
            }
            $supplierToWarehouse[$s2wKey]['qty'] += $qty;

            // Aggregate Warehouse -> Product
            $w2pKey = $warehouseName . '|' . $productName;
            if (!isset($warehouseToProduct[$w2pKey])) {
                $warehouseToProduct[$w2pKey] = ['from' => 'Warehouse: ' . $warehouseName, 'to' => 'Product: ' . $productName, 'qty' => 0];
            }
            $warehouseToProduct[$w2pKey]['qty'] += $qty;
        }

        foreach ($supplierToWarehouse as $edge) {
            $this->inventoryFlow[] = [$edge['from'], $edge['to'], $edge['qty']];
        }
        foreach ($warehouseToProduct as $edge) {
            $this->inventoryFlow[] = [$edge['from'], $edge['to'], $edge['qty']];
        }
    }
}; ?>

<div class="py-12 bg-gray-50 min-h-screen">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        
        <div class="mb-8 md:flex md:items-center md:justify-between">
            <div class="flex-1 min-w-0">
                <h2 class="text-3xl font-black leading-7 text-gray-900 sm:text-4xl sm:truncate tracking-tight">
                    Inventory Analytics & Data Flow
                </h2>
                <p class="mt-2 text-sm text-gray-500 font-medium">
                    Visualizing the flow of goods from Suppliers, through Warehouses, down to the specific Products.
                </p>
            </div>
        </div>

        <div class="grid grid-cols-1 gap-8 mb-8">
            <div class="bg-white rounded-3xl p-6 shadow-sm border border-gray-150 relative overflow-hidden">
                <h3 class="text-lg font-black text-gray-900 mb-2">Supply Chain Tracing (DFD)</h3>
                <p class="text-sm text-gray-500 mb-6">Traces total historical quantities received from each supplier.</p>
                <div id="sankey_inventory" style="width: 100%; height: 600px;" wire:ignore></div>
            </div>
        </div>

    </div>

    <!-- Apache Echarts Sankey -->
    <script src="https://cdn.jsdelivr.net/npm/echarts@5.5.0/dist/echarts.min.js"></script>
    <script>
        document.addEventListener('livewire:initialized', () => {
            const flowDataRaw = @json($inventoryFlow);
            
            if (flowDataRaw.length === 0) return;

            // Process data for Echarts
            const nodesMap = new Set();
            const links = [];
            
            flowDataRaw.forEach(item => {
                nodesMap.add(item[0]);
                nodesMap.add(item[1]);
                links.push({
                    source: item[0],
                    target: item[1],
                    value: item[2]
                });
            });

            const data = Array.from(nodesMap).map(name => ({ name }));

            const chartDom = document.getElementById('sankey_inventory');
            const myChart = echarts.init(chartDom);
            
            const option = {
                tooltip: {
                    trigger: 'item',
                    triggerOn: 'mousemove',
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    borderColor: '#e2e8f0',
                    borderWidth: 1,
                    padding: [10, 15],
                    textStyle: { color: '#1e293b', fontSize: 14, fontFamily: 'Inter' }
                },
                series: {
                    type: 'sankey',
                    layout: 'none',
                    emphasis: { focus: 'adjacency' },
                    nodeAlign: 'left',
                    data: data,
                    links: links,
                    lineStyle: {
                        color: 'gradient',
                        curveness: 0.5,
                        opacity: 0.4
                    },
                    itemStyle: {
                        borderWidth: 0,
                        borderColor: '#fff',
                        borderRadius: 4
                    },
                    label: {
                        color: '#1e293b',
                        fontFamily: 'Inter',
                        fontSize: 13,
                        fontWeight: '600'
                    },
                    color: [
                        '#6366f1', '#10b981', '#f59e0b', '#ef4444', 
                        '#8b5cf6', '#ec4899', '#06b6d4', '#f43f5e', 
                        '#14b8a6', '#f59e0b'
                    ]
                }
            };

            myChart.setOption(option);
            
            window.addEventListener('resize', function() {
                myChart.resize();
            });
        });
    </script>
</div>
